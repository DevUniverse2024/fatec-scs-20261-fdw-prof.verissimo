// Simulação do Banco de Dados
let veiculos = [];

// Seleção dos elementos do DOM para facilitar o uso
const inputMarca = document.getElementById('marca');
const inputModelo = document.getElementById('modelo');
const inputAno = document.getElementById('ano');
const tabelaCorpo = document.getElementById('listaCorpo');

// --- FUNÇÕES DE APOIO ---

// Função para limpar os campos após uma operação
function limparCampos() {
    inputMarca.value = '';
    inputModelo.value = '';
    inputAno.value = '';
    inputMarca.focus();
}

// Função que renderiza a tabela sempre que houver mudanças
function atualizarTabela() {
    tabelaCorpo.innerHTML = ''; // Limpa a tabela atual

    if (veiculos.length === 0) {
        tabelaCorpo.innerHTML = `<tr><td colspan="4" style="text-align:center;">Nenhum veículo no estoque.</td></tr>`;
        return;
    }

    veiculos.forEach((carro, index) => {
        const linha = `
            <tr>
                <td>${index + 1}</td>
                <td>${carro.marca}</td>
                <td>${carro.modelo}</td>
                <td>${carro.ano}</td>
            </tr>
        `;
        tabelaCorpo.innerHTML += linha;
    });
}

// --- OPERAÇÕES DO CRUD ---

// 1. INCLUIR
document.getElementById('btnIncluir').addEventListener('click', () => {
    const novoVeiculo = {
        marca: inputMarca.value,
        modelo: inputModelo.value,
        ano: inputAno.value
    };

    if (novoVeiculo.marca && novoVeiculo.modelo && novoVeiculo.ano) {
        veiculos.push(novoVeiculo);
        limparCampos();
        atualizarTabela();
    } else {
        alert("Por favor, preencha todos os campos da Maranelo!");
    }
});

// 2. CONSULTAR (Busca por modelo e preenche os campos)
document.getElementById('btnConsultar').addEventListener('click', () => {
    const busca = inputModelo.value.toLowerCase();
    const encontrado = veiculos.find(v => v.modelo.toLowerCase() === busca);

    if (encontrado) {
        inputMarca.value = encontrado.marca;
        inputAno.value = encontrado.ano;
        alert("Veículo localizado no estoque!");
    } else {
        alert("Veículo não encontrado.");
    }
});

// 3. ALTERAR (Baseado no modelo digitado)
document.getElementById('btnAlterar').addEventListener('click', () => {
    const modeloBusca = inputModelo.value.toLowerCase();
    const index = veiculos.findIndex(v => v.modelo.toLowerCase() === modeloBusca);

    if (index !== -1) {
        veiculos[index].marca = inputMarca.value;
        veiculos[index].ano = inputAno.value;
        atualizarTabela();
        alert("Dados atualizados com sucesso!");
    } else {
        alert("Para alterar, digite o modelo exato que já existe no sistema.");
    }
});

// 4. EXCLUIR
document.getElementById('btnExcluir').addEventListener('click', () => {
    const modeloBusca = inputModelo.value.toLowerCase();
    const index = veiculos.findIndex(v => v.modelo.toLowerCase() === modeloBusca);

    if (index !== -1) {
        if (confirm(`Deseja realmente remover o ${veiculos[index].modelo} do sistema?`)) {
            veiculos.splice(index, 1);
            limparCampos();
            atualizarTabela();
        }
    } else {
        alert("Modelo não encontrado para exclusão.");
    }
});