let veiculos = [];

const inputMarca = document.getElementById('marca');
const inputModelo = document.getElementById('modelo');
const inputAno = document.getElementById('ano');
const inputPreco = document.getElementById('preco');
const inputCor = document.getElementById('cor');
const tabelaCorpo = document.getElementById('listaCorpo');

// LIMPAR CAMPOS
function limparCampos() {
    inputMarca.value = '';
    inputModelo.value = '';
    inputAno.value = '';
    inputPreco.value = '';
    inputCor.value = '';
}

// ATUALIZAR TABELA
function atualizarTabela(lista = veiculos) {
    tabelaCorpo.innerHTML = '';

    if (lista.length === 0) {
        tabelaCorpo.innerHTML = `<tr><td colspan="6">Nenhum veículo.</td></tr>`;
        return;
    }

    lista.forEach((carro, index) => {
        tabelaCorpo.innerHTML += `
            <tr>
                <td>${index + 1}</td>
                <td>${carro.marca}</td>
                <td>${carro.modelo}</td>
                <td>${carro.ano}</td>
                <td>R$ ${parseFloat(carro.preco).toFixed(2)}</td>
                <td>${carro.cor}</td>
            </tr>
        `;
    });
}

// INCLUIR
document.getElementById('btnIncluir').addEventListener('click', () => {
    const novo = {
        marca: inputMarca.value,
        modelo: inputModelo.value,
        ano: inputAno.value,
        preco: inputPreco.value,
        cor: inputCor.value
    };

    if (novo.marca && novo.modelo && novo.ano && novo.preco && novo.cor) {
        veiculos.push(novo);
        limparCampos();
        atualizarTabela();
    } else {
        alert("Preencha todos os campos!");
    }
});

// CONSULTAR POR MARCA (FILTER)
document.getElementById('btnConsultar').addEventListener('click', () => {
    const busca = inputMarca.value.toLowerCase();

    const filtrados = veiculos.filter(v =>
        v.marca.toLowerCase().includes(busca)
    );

    atualizarTabela(filtrados);
});

// ALTERAR
document.getElementById('btnAlterar').addEventListener('click', () => {
    const modeloBusca = inputModelo.value.toLowerCase();

    const index = veiculos.findIndex(v =>
        v.modelo.toLowerCase() === modeloBusca
    );

    if (index !== -1) {
        veiculos[index] = {
            marca: inputMarca.value,
            modelo: inputModelo.value,
            ano: inputAno.value,
            preco: inputPreco.value,
            cor: inputCor.value
        };

        atualizarTabela();
        alert("Atualizado!");
    } else {
        alert("Modelo não encontrado.");
    }
});

// EXCLUIR
document.getElementById('btnExcluir').addEventListener('click', () => {
    const modeloBusca = inputModelo.value.toLowerCase();

    const index = veiculos.findIndex(v =>
        v.modelo.toLowerCase() === modeloBusca
    );

    if (index !== -1) {
        veiculos.splice(index, 1);
        atualizarTabela();
        limparCampos();
    } else {
        alert("Modelo não encontrado.");
    }
});

// REAJUSTE DE PREÇOS (FOREACH)
document.getElementById('btnReajuste').addEventListener('click', () => {
    const porcentagem = parseFloat(prompt("Digite % de aumento:"));

    if (isNaN(porcentagem)) {
        alert("Valor inválido.");
        return;
    }

    veiculos.forEach(carro => {
        carro.preco = parseFloat(carro.preco) * (1 + porcentagem / 100);
    });

    atualizarTabela();
    alert("Preços atualizados!");
});