// Array que funciona como nosso banco de dados em memória
let veiculos = [];

// Pegando os campos do formulário pelo ID
const inputMarca = document.getElementById('marca');
const inputModelo = document.getElementById('modelo');
const inputAno = document.getElementById('ano');
const inputCor = document.getElementById('cor');
const inputPreco = document.getElementById('preco');
const tabelaCorpo = document.getElementById('listaCorpo');

// Função para limpar os campos depois de uma operação
function limparCampos() {
    inputMarca.value = '';
    inputModelo.value = '';
    inputAno.value = '';
    inputCor.value = '';
    inputPreco.value = '';
    inputMarca.focus();
}

// Função que redesenha a tabela com os dados atuais
// Aceita um parâmetro opcional para exibir um subconjunto filtrado
function atualizarTabela(dados = veiculos) {
    tabelaCorpo.innerHTML = '';

    if (dados.length === 0) {
        tabelaCorpo.innerHTML = `<tr><td colspan="6" style="text-align:center;">Nenhum veículo encontrado.</td></tr>`;
        return;
    }

    // Percorre cada veículo e monta uma linha na tabela
    dados.forEach((veiculo, index) => {
        const linha = `
            <tr>
                <td>${index + 1}</td>
                <td>${veiculo.marca}</td>
                <td>${veiculo.modelo}</td>
                <td>${veiculo.ano}</td>
                <td>${veiculo.cor}</td>
                <td>R$ ${parseFloat(veiculo.preco).toFixed(2)}</td>
            </tr>
        `;
        tabelaCorpo.innerHTML += linha;
    });
}

// --- BOTÃO INCLUIR ---
// Cria um novo objeto veículo e adiciona no array
document.getElementById('btnIncluir').addEventListener('click', () => {
    const novoVeiculo = {
        marca: inputMarca.value.trim(),
        modelo: inputModelo.value.trim(),
        ano: inputAno.value.trim(),
        cor: inputCor.value.trim(),
        preco: inputPreco.value.trim()
    };

    // Verifica se todos os campos foram preenchidos
    if (!novoVeiculo.marca || !novoVeiculo.modelo || !novoVeiculo.ano || !novoVeiculo.cor || !novoVeiculo.preco) {
        alert('Preencha todos os campos antes de incluir!');
        return;
    }

    veiculos.push(novoVeiculo);
    limparCampos();
    atualizarTabela();
    alert('Veículo incluído com sucesso!');
});

// --- BOTÃO CONSULTAR ---
// Busca pelo modelo digitado e preenche os campos com os dados encontrados
// Usa o método .find() para localizar o primeiro resultado
document.getElementById('btnConsultar').addEventListener('click', () => {
    const busca = inputModelo.value.trim().toLowerCase();

    if (!busca) {
        alert('Digite o modelo para consultar.');
        return;
    }

    const encontrado = veiculos.find(v => v.modelo.toLowerCase() === busca);

    if (encontrado) {
        inputMarca.value = encontrado.marca;
        inputModelo.value = encontrado.modelo;
        inputAno.value = encontrado.ano;
        inputCor.value = encontrado.cor;
        inputPreco.value = encontrado.preco;
        alert('Veículo encontrado!');
    } else {
        alert('Nenhum veículo com esse modelo foi encontrado.');
    }
});

// --- BOTÃO ALTERAR ---
// Localiza o veículo pelo modelo e atualiza todos os campos com os valores digitados
document.getElementById('btnAlterar').addEventListener('click', () => {
    const busca = inputModelo.value.trim().toLowerCase();

    if (!busca) {
        alert('Digite o modelo do veículo que deseja alterar.');
        return;
    }

    const index = veiculos.findIndex(v => v.modelo.toLowerCase() === busca);

    if (index !== -1) {
        // Atualiza todas as propriedades do objeto encontrado
        veiculos[index].marca = inputMarca.value.trim();
        veiculos[index].modelo = inputModelo.value.trim();
        veiculos[index].ano = inputAno.value.trim();
        veiculos[index].cor = inputCor.value.trim();
        veiculos[index].preco = inputPreco.value.trim();

        limparCampos();
        atualizarTabela();
        alert('Veículo alterado com sucesso!');
    } else {
        alert('Modelo não encontrado. Digite o modelo exato para alterar.');
    }
});

// --- BOTÃO EXCLUIR ---
// Remove o veículo do array pelo modelo digitado
document.getElementById('btnExcluir').addEventListener('click', () => {
    const busca = inputModelo.value.trim().toLowerCase();

    if (!busca) {
        alert('Digite o modelo do veículo que deseja excluir.');
        return;
    }

    const index = veiculos.findIndex(v => v.modelo.toLowerCase() === busca);

    if (index !== -1) {
        if (confirm(`Confirma a exclusão do ${veiculos[index].modelo}?`)) {
            veiculos.splice(index, 1);
            limparCampos();
            atualizarTabela();
            alert('Veículo removido do estoque.');
        }
    } else {
        alert('Modelo não encontrado para exclusão.');
    }
});

// --- BOTÃO FILTRAR ---
// Filtra o estoque por marca usando .filter()
// Atualiza a tabela sem mexer no array original
document.getElementById('btnFiltrar').addEventListener('click', () => {
    const busca = inputMarca.value.trim().toLowerCase();

    if (!busca) {
        // Campo vazio: mostra todos os veículos
        atualizarTabela(veiculos);
        return;
    }

    const resultado = veiculos.filter(v => v.marca.toLowerCase().includes(busca));
    atualizarTabela(resultado);
});

// --- BOTÃO REAJUSTAR PREÇOS ---
// Usa .forEach() para aplicar um percentual de aumento em todos os veículos do estoque
document.getElementById('btnReajustar').addEventListener('click', () => {
    if (veiculos.length === 0) {
        alert('Estoque vazio, nada para reajustar!');
        return;
    }

    const percentual = parseFloat(prompt('Digite o percentual de reajuste (ex: 10 para 10%):'));

    if (isNaN(percentual) || percentual <= 0) {
        alert('Percentual inválido!');
        return;
    }

    // .forEach() percorre todos os veículos e aplica o reajuste no preço
    veiculos.forEach(veiculo => {
        const precoAtual = parseFloat(veiculo.preco);
        veiculo.preco = (precoAtual * (1 + percentual / 100)).toFixed(2);
    });

    atualizarTabela();
    alert(`Reajuste de ${percentual}% aplicado em ${veiculos.length} veículo(s)!`);
});
