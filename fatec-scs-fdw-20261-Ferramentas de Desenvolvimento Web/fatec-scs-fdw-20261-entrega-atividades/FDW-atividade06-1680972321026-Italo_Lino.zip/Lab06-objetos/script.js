// Simulação do Banco de Dados
let veiculos = [];

// Seleção dos elementos do DOM para facilitar o uso
const inputMarca = document.getElementById('marca');
const inputModelo = document.getElementById('modelo');
const inputAno = document.getElementById('ano');
const inputCor = document.getElementById('cor');
const inputPreco= document.getElementById('preco');
const tabelaCorpo = document.getElementById('listaCorpo');

// --- FUNÇÕES DE APOIO ---

// Função para limpar os campos após uma operação
function limparCampos() {
    inputMarca.value = '';
    inputModelo.value = '';
    inputAno.value = '';
    inputPreco.value = '';
    inputCor.value = '';
    inputMarca.focus();
}

// Função que renderiza a tabela sempre que houver mudanças
function atualizarTabela(dados = veiculos) {
    tabelaCorpo.innerHTML = ''; // Limpa a tabela atual

    if (dados.length === 0) {
        tabelaCorpo.innerHTML = `<tr><td colspan="6" style="text-align:center;">Nenhum veículo encontrado.</td></tr>`;
        return;
    }

    dados.forEach((carro, index) => {
        // Encontra o índice real no array original para mostrar numeração correta
        const indiceReal = veiculos.findIndex(v => v.marca === carro.marca && v.modelo === carro.modelo && v.ano === carro.ano);
        const numeroMostrar = indiceReal !== -1 ? indiceReal + 1 : index + 1;
        
        const linha = `
            <tr>
                <td>${numeroMostrar}</td>
                <td>${carro.marca}</td>
                <td>${carro.modelo}</td>
                <td>${carro.ano}</td>
                <td>${carro.cor}</td>
                <td>${carro.preco}</td>
            </tr>
        `;
        tabelaCorpo.innerHTML += linha;
    });
}

// --- OPERAÇÕES DO CRUD ---

// 1. INCLUIR
document.getElementById('btnIncluir').addEventListener('click', () => {
    const novoVeiculo = {
        marca: inputMarca.value,
        modelo: inputModelo.value,
        ano: inputAno.value,
        cor: inputCor.value,
        preco: inputPreco.value
    };

    if (novoVeiculo.marca && novoVeiculo.modelo && novoVeiculo.ano && novoVeiculo.cor && novoVeiculo.preco) {
        veiculos.push(novoVeiculo);
        limparCampos();
        atualizarTabela();
    } else {
        alert("Por favor, preencha todos os campos da Maranelo!");
    }
});
  -
//2. CONSULTAR (Busca por modelo e preenche os campos)
document.getElementById('btnConsultar').addEventListener('click', () => {
    const busca = inputMarca.value.toLowerCase();
    const encontrado = veiculos.find(v => v.marca.toLowerCase() === busca);

    if (encontrado) {
        inputMarca.value = encontrado.marca;
        inputAno.value = encontrado.ano;
        alert("Veículo localizado no estoque!");
    } else {
        alert("Veículo não encontrado.");
    }
});

// 3. ALTERAR (Baseado no modelo digitado)
document.getElementById('btnAlterar').addEventListener('click', () => {
    const modeloBusca = inputModelo.value.toLowerCase();
    const index = veiculos.findIndex(v => v.modelo.toLowerCase() === modeloBusca);

    if (index !== -1) {
        veiculos[index].marca = inputMarca.value;
        veiculos[index].ano = inputAno.value;
        atualizarTabela();
        alert("Dados atualizados com sucesso!");
    } else {
        alert("Para alterar, digite o modelo exato que já existe no sistema.");
    }
});

// 4. EXCLUIR
document.getElementById('btnExcluir').addEventListener('click', () => {
    const modeloBusca = inputModelo.value.toLowerCase();
    const index = veiculos.findIndex(v => v.modelo.toLowerCase() === modeloBusca);

    if (index !== -1) {
        if (confirm(`Deseja realmente remover o ${veiculos[index].modelo} do sistema?`)) {
            veiculos.splice(index, 1);
            limparCampos();
            atualizarTabela();
        }
    } else {
        alert("Modelo não encontrado para exclusão.");
    }
});
//5. Filtrar
document.getElementById('btnFiltrar').addEventListener('click', () => {
    const busca = inputMarca.value.toLowerCase(); // <-- FALTAVA ESTA LINHA
    
    if (busca === '') {
        // Se o campo estiver vazio, mostra todos
        atualizarTabela(veiculos);
    } else {
        const filtroMarca = veiculos.filter(v => v.marca.toLowerCase().includes(busca));
        
        if (filtroMarca.length === 0) {
            tabelaCorpo.innerHTML = `<tr><td colspan="6" style="text-align:center;">Nenhum veículo encontrado para a marca "${busca}"</td></tr>`;
        } else {
            atualizarTabela(filtroMarca);
        }
    }
});
// 6. REAJUSTE DE PREÇOS 
document.getElementById('btnReajustar')?.addEventListener('click', () => {
    if (veiculos.length === 0) {
        alert('Estoque vazio!');
        return;
    }
    
    const percentual = parseFloat(prompt('Digite a porcentagem de aumento:', '10'));
    
    if (isNaN(percentual)) {
        alert('Valor inválido!');
        return;
    }
    
    // USANDO .forEach() - Aplicando reajuste em todos os veículos
    veiculos.forEach(veiculo => {
        const precoAtual = parseFloat(veiculo.preco);
        const novoPreco = precoAtual * (1 + percentual / 100);
        veiculo.preco = novoPreco.toFixed(2);
    });
    
    alert(`${percentual}% de reajuste aplicado em ${veiculos.length} veículo(s)!`);
    atualizarTabela(); // Atualiza a tabela com os novos preços
});